# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '0d9b85abdbd8507f720bc3ae3e73c030c2eaf6aa48b9b0e73fcdc39f1e62b2acc6a79c1177a71d6268908ca3304fd9023472a284f0686ade12c70cf5522b8dbd'